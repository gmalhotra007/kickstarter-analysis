# kickstarter-analysis
Performing analysis on Kickstarted data to uncover trends
